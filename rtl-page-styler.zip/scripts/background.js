chrome.runtime.onInstalled.addListener(() => {
  console.log("Right-to-Left Styler Installed");
});
